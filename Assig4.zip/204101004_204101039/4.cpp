#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include<fstream>

using namespace std;

int num_phil = 5;		// number of philosophers
int phil_eaten[5];		// array to check whether the philosopher has eaten or not
int fork_status[5];		// chopsticks status
pthread_mutex_t p_fork;	// mutex lock
pthread_cond_t cond[5];	// conditional lock

ofstream MyFile("output.txt");

bool all_phil_eaten()		// to check philosopher has eaten atleast once
{
	int sum=0;
	for(int i=0;i<5;i++)
	{
		sum+=phil_eaten[i];
	}
	if(sum==5)
		return 1;
	else
		return 0;
}

bool fork_check(int id)	// to check whether fork is available to pick
{
	if(fork_status[id]==1 && fork_status[(id+1)%5]==1)
	{
		fork_status[id]=0;
		fork_status[(id+1)%5]=0;
		cout<<"Philosopher "<<id<<" picks fork "<<id<<" and "<<(id+1)%5<<" and is eating."<<endl;
		MyFile<<"Philosopher "<<id<<" picks fork "<<id<<" and "<<(id+1)%5<<" and is eating."<<endl;
		return true;
	}
	return false;
}

void pick_fork(int id)		// function to pick fork by the philosopher
{
	pthread_mutex_lock(&p_fork);
	cout<<"Philosopher "<<id<<" is hungry."<<endl;
	MyFile<<"Philosopher "<<id<<" is hungry."<<endl;
	while(fork_check(id)==false)
	{
		pthread_cond_wait(&cond[id],&p_fork);
	}
	phil_eaten[id]=1;
	pthread_mutex_unlock(&p_fork);
	sleep(1);
}

void drop_fork(int id)		// function to drop fork by the philosopher
{
	pthread_mutex_lock(&p_fork);
	fork_status[id]=1;
	fork_status[(id+1)%5]=1;
	cout<<"Philosopher "<<id<<" put down the fork "<<id<<" and "<<(id+1)%5<<" and has started thinking."<<endl;
	MyFile<<"Philosopher "<<id<<" put down the fork "<<id<<" and "<<(id+1)%5<<" and has started thinking."<<endl;
	pthread_cond_signal(&cond[(id+4)%5]);
	pthread_cond_signal(&cond[(id+1)%5]);
	pthread_mutex_unlock(&p_fork);
}

void *philosopher(void *arg)		// thread initilization
{
	while(!all_phil_eaten())
	{
		int *p = (int *)arg;
		int tid = *p;
		sleep(1);
		pick_fork(tid);
		sleep(1);
		drop_fork(tid);
	}
}

int main()
{
	for(int i=0;i<5;i++)
		pthread_cond_init(&cond[i],NULL);
	for(int i=0;i<5;i++)
	{
		phil_eaten[i]=0;
		fork_status[i]=1;
	}
	int t_num[5];
	pthread_t phil_id[5];
	for(int i=0;i<5;i++)
	{
		t_num[i]=i;
		pthread_create(&phil_id[i],NULL,philosopher,&t_num[i]);		// creating thread
		cout<<"Philosopher "<<t_num[i]<<" is created."<<endl;
		MyFile<<"Philosopher "<<t_num[i]<<" is created."<<endl;
	}
	for(int i=0;i<5;i++)
	{
		pthread_join(phil_id[i],NULL);
	}
	return 0;
}
