Group Information : 

1. Ajay Gahlot (204101004)
2. Nishant Bharti ( 204101039)


To  compile program 2:

g++ 2.cpp -lpthread

./a.out

To compile program 3: 

g++ 3.cpp -lpthread

./a.out


To compile program 4: 

g++ 4.cpp -lpthread

./a.out
