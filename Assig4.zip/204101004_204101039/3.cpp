#include<iostream>

#include<pthread.h>

#include<unistd.h>

/* there can be maximum "no_of_waiting chairs" can wait (exculding one currently with doctor) if chais full then patient discarded*/

using namespace std;

int no_of_waiting_chairs; // no of chairs for waiting patient

class Monitor
{
	private:
		int no_of_patient_currently_waiting;
		
		bool is_doctor_free;
		
		pthread_cond_t cond_variable;
		
		pthread_mutex_t lock_mutex;
		
	public:
		Monitor()
		{
			is_doctor_free = true;
			no_of_patient_currently_waiting = 0;
			pthread_cond_init(&cond_variable,NULL);
			pthread_mutex_init(&lock_mutex,NULL);
		}
		
		bool doctor_check_patient(int patient_id)
		{
			pthread_mutex_lock(&lock_mutex);
			
			cout<<"Patient "<<patient_id<<" arrived in the clinic\n";
		
			if(is_doctor_free == false && no_of_patient_currently_waiting < no_of_waiting_chairs)
			{
				no_of_patient_currently_waiting++;
				pthread_cond_wait(&cond_variable,&lock_mutex);
				no_of_patient_currently_waiting--;
			}
			else if(is_doctor_free == false)
			{
				cout<<"No of waiting chairs are full the Patient "<<patient_id<<" is discarded\n";
				pthread_mutex_unlock(&lock_mutex);
				return false;	
			}
			is_doctor_free = false;
			cout<<"Patient "<<patient_id<<" getting vaccinated\n";
			pthread_mutex_unlock(&lock_mutex);
			return true;
		}
		
		void doctor_check_patient_end(int patient_id)
		{
			pthread_mutex_lock(&lock_mutex);
			
			cout<<"Patient "<<patient_id<<" vaccination over\n";
			if(no_of_patient_currently_waiting == 0)
			{
				is_doctor_free = true;
			}
			
			pthread_mutex_unlock(&lock_mutex);
			pthread_cond_signal(&cond_variable);
		}	
}Monitor_object;			

int counter = 0;
void* vaccination_function(void* temp)
{
	int patient_id = counter++;
	if(Monitor_object.doctor_check_patient(patient_id) == true)
	{
	
		sleep(0.1);
		Monitor_object.doctor_check_patient_end(patient_id);
	}
	return NULL;
}



int main()
{
	int no_of_patients;
	cout<<"Enter the no of waiting chairs\n";
	
	cin>>no_of_waiting_chairs;
	
	cout<<"Enter the no of patient\n";
	
	cin>>no_of_patients;
	
	pthread_t Patient_thread[no_of_patients];
	
	for(int i=0;i<no_of_patients;i++)
	{
		pthread_create(&Patient_thread[i],NULL,&vaccination_function,NULL);
	
	}
	
	for(int i=0;i<no_of_patients;i++)
	{
		pthread_join(Patient_thread[i],NULL);
	}
}
