#include <pthread.h>
#include <stdio.h>
#include<queue>
#include<stdlib.h>
#include <unistd.h>
#include <time.h>
#include<iostream>


/* Alternatively one vehicel from left side and one vehicle from right side are send inside the tunnel if no vehicle waiting in other side then from same side again vehicle will be send*/

using namespace std;

pthread_mutex_t lock_arrival = PTHREAD_MUTEX_INITIALIZER,lock_depart = PTHREAD_MUTEX_INITIALIZER;

pthread_cond_t cond_var_left = PTHREAD_COND_INITIALIZER,cond_var_right = PTHREAD_COND_INITIALIZER;

int current_direction_of_the_tunnel = 0; // 0 ---> no direction 1---> left to right 2----> right to left

int no_curr_vehicles_inside_tunnel = 0;

int vehicle_waiting_left_side = 0,vehicle_waiting_right_side = 0;

void arrival_function(int vehicle_id,int direction_of_the_vehicle)
{
	pthread_mutex_lock(&lock_arrival);
	
	printf("%d is waiting for entering in the tunnel ",vehicle_id);
	if(direction_of_the_vehicle == 1)
	{
		printf(": direction left to right\n");
	}
	else
	{
		printf(" : direction right to left\n");
	}
	int curr_waiting_other_direction; 
	
	if(direction_of_the_vehicle == 1)
	{
		curr_waiting_other_direction = vehicle_waiting_right_side;
	}
	else
	{
		 curr_waiting_other_direction = vehicle_waiting_left_side;
	}
	if(current_direction_of_the_tunnel != 0)
	{
	
		
		if(direction_of_the_vehicle == 1)
		{
			vehicle_waiting_left_side++;
			pthread_cond_wait(&cond_var_left,&lock_arrival);
		}
		else
		{
			vehicle_waiting_right_side++;
			pthread_cond_wait(&cond_var_right,&lock_arrival);
		}
		if(direction_of_the_vehicle == 1)
		{
			vehicle_waiting_left_side--;
		}
		else
		{
			vehicle_waiting_right_side--;
		}
	}
	printf("%d entered in tunnel",vehicle_id);
	
	if(direction_of_the_vehicle == 1)
	{
		printf(" : direction left to right\n");
	}
	else
	{
		printf(" : direction right to left\n");
	}
	
	current_direction_of_the_tunnel  = direction_of_the_vehicle ;
	
	no_curr_vehicles_inside_tunnel++;
	
	pthread_mutex_unlock(&lock_arrival);
	
}


int departure_function(int vehicle_id,int direction_of_the_vehicle)
{	
	
	
	pthread_mutex_lock(&lock_depart);
	no_curr_vehicles_inside_tunnel--;
	printf("%d is departing from the tunnel",vehicle_id);
	if(direction_of_the_vehicle == 1)
	{
		printf(" : direction left to right\n");
	}
	else
	{
		printf(" : direction right to left\n");
	}
	if(no_curr_vehicles_inside_tunnel == 0)
	{
		
		if(current_direction_of_the_tunnel == 1)
		{
			if(vehicle_waiting_right_side > 0)
			{
				//cout<<"hello\n";
				pthread_cond_signal(&cond_var_right);
			}
			else if(vehicle_waiting_left_side> 0)
			{
				pthread_cond_signal(&cond_var_left);
			}
		}
		else
		{
			if(vehicle_waiting_left_side > 0)
			{
				//cout<<"hello\n";
				pthread_cond_signal(&cond_var_left);
			}
			else if(vehicle_waiting_right_side > 0)
			{
				pthread_cond_signal(&cond_var_right);
			}
		}
		current_direction_of_the_tunnel = 0;
	}
	
	pthread_mutex_unlock(&lock_depart);
}
int vehicle_counter = 0;

void* vehicle_controller_function(void* temp)
{

	int vehicle_id = vehicle_counter++;
	int direction_of_the_vehicle  = 1 + rand()%2; // direction generated randomly 1 --> left to right 2---> right to left
	arrival_function(vehicle_id,direction_of_the_vehicle);
	sleep(0.5);
	departure_function(vehicle_id,direction_of_the_vehicle);
	return NULL;
}

int main()
{
	int no_of_vehicles;
	cout<<"Enter the no of vehicles\n";
	cin>>no_of_vehicles;
	srand(time(0));
	pthread_t vehicles_thread[no_of_vehicles];
	
	for(int i=0;i<no_of_vehicles;i++)
	{
		pthread_create(&vehicles_thread[i],NULL,vehicle_controller_function,NULL);
	}
	for(int i=0;i<no_of_vehicles;i++)
	{
		pthread_join(vehicles_thread[i],NULL);
	}
	

	return 0;
}

