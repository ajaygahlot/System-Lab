#include<iostream>
#include<utility>
#include<queue>
#include<algorithm>
using namespace std;


/* higher value means higher priority*/

/* if priority same then which comes first have greater priority*/


#define n 9 // no of process(equals to no of digit int roll no)

struct Process
{
	int process_id;
	int arrival_time;
	int burst_time;
	int priority;
	int completation_time;
	int turn_around_time;
	int waiting_time;
};


bool comparator(struct Process &p1,struct Process &p2)
{
	if(p1.arrival_time < p2.arrival_time) return true;
		else if(p1.arrival_time > p2.arrival_time) return false;
		else if(p1.process_id > p2.process_id) return false;
		return true;
}


struct compareProcess
{
	bool operator()(Process const &p1,Process const &p2)
	{
		if(p1.priority < p2.priority)	return true;
		else if(p1.priority > p2.priority) return false;
		else if(p1.arrival_time > p2.arrival_time) return true;
		else if(p1.arrival_time < p2.arrival_time) return false;
		else if(p1.process_id < p2.process_id) return false;
		return true;
	}
};
		
int main()
{
	int roll_no;
	cout<<"Enter the 9 digit roll no\n";
	cin>>roll_no;
	
	struct Process process[n];
	
	int temp[n];
	
	int i=0;
	while(i<n)
	{
		temp[n-i-1] = roll_no%10;
		roll_no = roll_no/10;
		i=i+1;
	}
	int burst_time_temp[n];
	int arrival_time_temp[n];
	/* priority */
	
	for(int i=0;i<n;i++)
	{
		 process[i].process_id = i+1;
		 process[i].priority = temp[i];
		 process[i].arrival_time = temp[n-i-1];
		 process[i].burst_time = (rand()%5) + 2;
		 burst_time_temp[i] = process[i].burst_time;
		 arrival_time_temp[i] = process[i].arrival_time;
	}
	
	/* information of the process */
	cout<<"Information of Processes :\n";
	cout<<"Process id"<<" | "<<"Priority"<<" | "<<"Arrival time"<<" | "<<"Burst Time\n";
	for(int i=0;i<n;i++)
	{
		cout<<"      "<<process[i].process_id<<"    |    "<<process[i].priority<<"     |    "<<process[i].arrival_time<<"         |    "<<process[i].burst_time<<"\n";
	}
	
	// sort according to arrival time
	
	cout<<"\n-----------------------------------------------------------\n";
	
	cout<<"Sorted by arrival time : \n";
	sort(process,process+n,comparator);
	
	cout<<"Process id"<<" | "<<"Priority"<<" | "<<"Arrival time"<<" | "<<"Burst Time\n";
	for(int i=0;i<n;i++)
	{
		cout<<"      "<<process[i].process_id<<"    |    "<<process[i].priority<<"     |    "<<process[i].arrival_time<<"         |    "<<process[i].burst_time<<"\n";
	}
	
	cout<<"\n-------------------------------------------------------------\n";
	
	priority_queue<Process,vector<Process>,compareProcess>pq;
	
	cout<<"Gantt Chart : \n";
	i=0;
	int curr_time;
	int completation_time[n+1];
	while(i<n-1)
	{
			
		pq.push(process[i]);
		
		curr_time = process[i].arrival_time;
		 
		while(pq.empty() == false)
		{
			
			struct Process temp_process = pq.top();
			
			pq.pop();
			
			if(curr_time + temp_process.burst_time < process[i+1].arrival_time)
			{
				completation_time[temp_process.process_id] = curr_time + temp_process.burst_time;
				
				for(int j=0;j<temp_process.burst_time;j++)
				{
					cout<<" | P"<<temp_process.process_id<<" |";
				}
				curr_time = completation_time[temp_process.process_id];
				
				
			}
			else
			{
				temp_process.burst_time=   temp_process.burst_time - ( process[i+1].arrival_time - curr_time );
				for(int j=0;j<( process[i+1].arrival_time - curr_time );j++)
				{
					cout<<" | P"<<temp_process.process_id<<" |";
				}
				pq.push(temp_process);
				break;
			}
		}
		
		i = i + 1;
	}
	
	pq.push( process[n-1] );
	
//	cout<<curr_time<<"----------------\n";
	curr_time = process[n-1].arrival_time;
		
	while(pq.empty() == false)
	{
		
		
		struct Process temp_process = pq.top();
			
		pq.pop();
			
		
		completation_time[temp_process.process_id] = curr_time + temp_process.burst_time;
				
		for(int j=0;j<temp_process.burst_time;j++)
		{
			cout<<" | P"<<temp_process.process_id<<" |";
		}
		curr_time = completation_time[temp_process.process_id];
				
				
	}
		
	cout<<"\nCompletation time : \n";	
	for(int i=1;i<=n;i++)
	{
		process[i-1].completation_time = completation_time[i];
		cout<<"P"<<i<<" : ";
		cout<<completation_time[i]<<"\n";
	}
		
	int total_waiting_time = 0;
	cout<<"\nWaiting time : \n";
	for(int i=0;i<n;i++)
	{
		process[i].turn_around_time = process[i].completation_time - arrival_time_temp[i];
		process[i].waiting_time = process[i].turn_around_time - burst_time_temp[i];
		total_waiting_time += process[i].waiting_time; 
		cout<<"P"<<i+1<<" : ";
		cout<<process[i].waiting_time<<"\n";
	}		
	cout<<"Average waiting time : \n"<<total_waiting_time*1.0/n<<"\n";	
		
		
}
		
		
		
		
		
		
		
		
		
		
