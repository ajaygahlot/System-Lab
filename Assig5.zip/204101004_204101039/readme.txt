Group members -

1. Ajay Gahlot 204101004
2  Nishant Bharti 204101039

For question 1 --


simple compile and run the given file

Then User will be asked to input the Number of Boxes (Pages), Number of Slots (Frames) and Identification Number of All the Boxes (Pages)

Output will be: Number of Page faults, Number of Replacements (Page Faults - Slots), All the Pages that are replaced


For ques 2 -- 


input file as specified in the ques

compile -- g++ 2.cpp
run --- ./a.out input.txt FF ( can be change according to ques )

For ques 3 -- 

simple compile and run
