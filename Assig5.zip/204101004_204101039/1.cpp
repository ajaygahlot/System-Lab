#include <iostream>
#include <algorithm>
using namespace std;

int boxes,slots;
struct frame
{
	int value = -1;
	bool ref = false;
};

bool page_exist(int page, frame frames[])
{
	for(int i=0;i<slots;i++)
	{
		if(frames[i].value == page)
		{
			frames[i].ref = true;
			return true;
		}
	}
	return false;
}

int second_chance(int pages[],frame frames[])
{
	int ptr = 0;
	int page_faults = 0;
	cout<<endl;
	for(int i=0;i<boxes;i++)
	{
		if(page_exist(pages[i],frames))
		{
			//do nothing
		}
		else
		{
			while(frames[ptr].ref == true)
			{
				frames[ptr].ref = false;
				ptr = (ptr+1)%slots;
			}
			cout<<frames[ptr].value<<" is replaced by "<<pages[i]<<endl;
			frames[ptr].ref = false;
			frames[ptr].value = pages[i];
			ptr = (ptr+1)%slots;
			page_faults++;
		}
		/*cout<<"Iteration number: "<<i+1<<" : ";
		for(int i=0;i<slots;i++)
		{
			cout<<frames[i].value<<" - "<<frames[i].ref<<"		";
		}
		cout<<endl;*/
	}
	return page_faults;
}

int main()
{
	cout<<"Enter the number of boxes"<<endl;
	cin>>boxes;
	cout<<"Enter the number of slots"<<endl;
	cin>>slots;
	
	if(slots>boxes)
	{
		cout<<"Slots cannot be greater than blocks"<<endl;
		exit(0);
	}
	
	int pages[boxes];
	frame frames[slots];
	cout<<"Enter box identification numbers"<<endl;
	for(int i=0;i<boxes;i++)
	{
		cout<<"Enter id number for box "<<i<<" : ";
		cin>>pages[i];
		if(pages[i]<0)
		{
			cout<<"Enter a positive id number"<<endl;
			i--;
		}	
		
	}

	int page_f = second_chance(pages,frames);
	cout<<endl;
	cout<<"Number of Page Faults are: "<<page_f<<endl;
	cout<<"Number of Replacements are: "<<max(0,page_f-slots)<<endl;
	
	return 0;
}
