#include<iostream>
#include<string.h>
#include<stdio.h>

using namespace std;


struct Inode
{

    char name[8];
    int size;
    int blockPointers[8];
    int used = 0;
};

struct Superblock
{
    char block_free[128] = {0};
    struct Inode inode[16];

};



struct Datablock
{
    char data[1024] = "";
};



class FileSystem
{
    struct Superblock super_block;
    struct Datablock data_block[127];
public:
    void create(char name[8],int size);
    void delete_file(char name[8]);
    void read(char name[8],int blocknum,char buf[1024]);
    void write(char name[8],int blocknum,char buf[1024]);
    void ls();
};


void FileSystem :: create(char name[8],int size)
{

    for(int i=0;i<16;i++)
    {

        if(super_block.inode[i].used == 1 && strcmp(super_block.inode[i].name,name) == 0)
        {
            cout<<"File with same name exist\n";
            return;
        }
    }
    for(int i=0;i<16;i++)
    {
        if(super_block.inode[i].used == 0)
        {
            // free inode found
            strcpy(super_block.inode[i].name,name);
            super_block.inode[i].size = size;
            super_block.inode[i].used = 1;

            // assign the data block
            int count  = 0;
            for(int j=1;j<128;j++)
            {
                if(super_block.block_free[j] == 0)
                {
                    super_block.block_free[j] == 1;
                    super_block.inode[i].blockPointers[count] = j-1; // i am storing block number

                    count = count + 1;
                    if(count == size)
                    {
                        break;
                    }
                }
            }
            return;
        }
    }
}

void FileSystem :: delete_file(char name[8])
{
    for(int i=0;i<16;i++)
    {
        if(super_block.inode[i].used == 1  && strcmp(super_block.inode[i].name,name) == 0) // reqd file found
        {
            super_block.inode[i].used = 0;
            for(int j=0;j<super_block.inode[i].size;j++)
            {
                super_block.block_free[super_block.inode[i].blockPointers[j]] = 0; // free the data block

            }
            return;
        }
    }
    cout<<"File not found\n";
}

void FileSystem :: read(char name[8],int blocknum,char buf[1024])
{
    for(int i=0;i<16;i++)
    {
        if(super_block.inode[i].used == 1  && strcmp(super_block.inode[i].name,name) == 0) // reqd file found
        {
            if(blocknum < super_block.inode[i].size)
            {

                int temp = super_block.inode[i].blockPointers[blocknum];
          //  cout<<data_block[temp].data<<"\n";
                strcpy(buf,data_block[temp].data);
                cout<<buf<<"\n";
                return;
            }
            else
            {
                cout<<"Wrong block number\n";
                return;
            }
        }
    }
    cout<<"File not found\n";
}

void FileSystem :: write(char name[8],int blocknum,char buf[1024])
{
    for(int i=0;i<16;i++)
    {
        if(super_block.inode[i].used == 1 && strcmp(super_block.inode[i].name,name) == 0) // reqd file found
        {
           // cout<<super_block.inode[i].size<<"\n";
            if(blocknum < super_block.inode[i].size)
            {

                int temp = super_block.inode[i].blockPointers[blocknum];
                strcpy(data_block[temp].data,buf);
                return;
            }
            else
            {
                cout<<"Wrong block number\n";
                return;
            }

        }
    }
    cout<<"File not found\n";
}

void FileSystem :: ls()
{
    cout<<"List of files with their size : \n";
    for(int i=0;i<16;i++)
    {
        if(super_block.inode[i].used == 1)
        {
            cout<<super_block.inode[i].name<<" "<<super_block.inode[i].size<<"\n";
        }
    }
}

int main()
{
    FileSystem file_system;

    int choice;



    while(true)
    {
        cout<<"1.Create the file\n2.Delete the file\n3.Write in the file\n4.Read from the file\n5.List of all files\n6.exit\n";
        cin>>choice;

        if(choice == 1)
        {
            char name[8];
            int size;
            cout<<"Enter the file name\n";
            cin>>name;
            cout<<"Enter the size of the file(in terms of no of blocks)\n";
            cin>>size;
            file_system.create(name,size);
        }
        else if(choice == 2)
        {
            char name[8];
            cout<<"Enter the file name to be deleted\n";
            cin>>name;
            file_system.delete_file(name);
        }
        else if(choice == 3)
        {
            char name[8];
            char buf[1024];
            int block_num;
            cout<<"Enter the filename\n";
            cin>>name;
            cout<<"enter the block number\n";
            cin>>block_num;
            cout<<"Enter the data\n";
            cin.ignore(256, '\n');
            cin.getline(buf, 1024);
            file_system.write(name,block_num,buf);
        }
        else if(choice == 4)
        {
            char name[8];
            char buf[1024];
            int block_num;
            cout<<"Enter the filename\n";
            cin>>name;
            cout<<"enter the block number\n";
            cin>>block_num;
            file_system.read(name,block_num,buf);
        }
        else if(choice == 5)
        {
            file_system.ls();
        }
        else
        {
            break;
        }
        cout<<"\n";
  /* //  file_system.create("file2",7);
//    file_system.ls();
   // file_system.delete_file("file1");
    file_system.ls();
    file_system.write("file1",0,"hello world");
    char temp[1024];
    file_system.read("file1",0,temp);
    cout<<temp<<"\n";
    cout<<"\n";*/
    }
}




