#include<iostream>
#include<vector>
#include<queue>
#include<set>
#include<fstream>
#include<cstring>
#include<sstream>
using namespace std;

int no_of_pages;

int no_of_frames;

vector<int>referenced_pages;

void tokenize(string const &str, const char delim,
            vector<string> &out)
{
    size_t start;
    size_t end = 0;
 
    while ((start = str.find_first_not_of(delim, end)) != string::npos)
    {
        end = str.find(delim, start);
        out.push_back(str.substr(start, end - start));
    }
}

void FIFO()
{

	queue<int>q;
	set<int>s;

	int page_fault = 0;

	for(int i=0;i<referenced_pages.size();i++)
	{
		if(s.find(referenced_pages[i]) == s.end())
		{
			page_fault++;
			// put page

			if(q.size() == no_of_frames)
			{
				int temp = q.front();
				q.pop();
				s.erase(temp);
				q.push(referenced_pages[i]);
				s.insert(referenced_pages[i]);
			}
			else
			{
				q.push(referenced_pages[i]);
				s.insert(referenced_pages[i]);
			}
		}

	}

	cout<<"using FIFO the no of page_fault is : "<<page_fault<<"\n";
}

void LRU()
{
	// least recenlty used

	int table[no_of_frames];
	int index[no_of_frames];
	memset(table,-1,sizeof(table));
	memset(index,-1,sizeof(table));
	int page_fault = 0;

	int count  = 0;
	for(int i=0;i<referenced_pages.size();i++)
	{
	
		int flag = 0;
		int curr_page = referenced_pages[i];
		for(int j=0;j<no_of_frames;j++)
		{
			if(table[j] == curr_page)
			{
				flag = 1;
				index[j] = i;
				break;
			}
		}
		if(flag == 0)
		{
			page_fault++;
			
			if(count == no_of_frames)
			{
				int min_index = 0;
				for(int j=0;j<no_of_frames;j++)
				{
					if(index[j] < index[min_index])
					{
						min_index = j;
					}
				}
				table[min_index] = curr_page;
				index[min_index] = i;
			}
			else
			{
				table[count]  = curr_page;
				index[count] = i;
				count++;
			}
		}
			
		//cout<<page_fault<<"\n";	

	}
	cout<<"using LRU the no of page_fault is : "<<page_fault<<"\n";

}

void LFU()
{
	// least recenlty used

	int table[no_of_frames];
	int counter_table[no_of_frames];
	int fifo_table[no_of_frames];
	memset(table,-1,sizeof(table));
	memset(counter_table,0,sizeof(table));
	memset(fifo_table,-1,sizeof(table));
	int page_fault = 0;

	int count  = 0;
	for(int i=0;i<referenced_pages.size();i++)
	{
	
		int flag = 0;
		int curr_page = referenced_pages[i];
		for(int j=0;j<no_of_frames;j++)
		{
			if(table[j] == curr_page)
			{
				flag = 1;
				counter_table[j]++;
				break;
			}
		}
		if(flag == 0)
		{
			page_fault++;
			
			if(count == no_of_frames)
			{
				int index = 0;
				for(int j=1;j<no_of_frames;j++)
				{
					if(counter_table[j] < counter_table[index])
					{
						index = j;
					}
					else if(counter_table[j] == counter_table[index])
					{
						if(fifo_table[j] < fifo_table[index])
						{
							index = j;
						}
					}
				}
				table[index] = curr_page;
				counter_table[index] = 1; 
				fifo_table[index] = i;
			}
			else
			{
				table[count]  = curr_page;
				counter_table[count] = 1; 
				fifo_table[count] = i;
				count++;
			}
		}
			
		//cout<<page_fault<<"\n";	

	}
	cout<<"using LFU the no of page_fault is : "<<page_fault<<"\n";
}

void read_file(string filename)
{
    ifstream file;
	file.open(filename);
	int num;
	if(file.is_open())
	{
		int count = 0;
		string line;
		while(getline(file,line))
		{

			//cout<<line<<"\n";
			
			if(line.length() > 0)
			{
				const char delim = ' ';

            			vector<string> out;

            			tokenize(line, delim, out);


 				if(count == 0)
 				{
                			no_of_pages = stoi(out[0]);
                			no_of_frames = stoi(out[1]);
 				}
 				else
            			{
            				//cout<<"bye world\n";
                			for(int i=0;i<out.size();i++)
                			{
                				//cout<<out[i].length()<<"\n";
                				if(out[i].length() > 0 && out[i][0] >= '0' && out[i][0] <='9')
                				{
                					int temp = stoi(out[i]);
                					referenced_pages.push_back(temp);
                				//	cout<<temp<<"\n";
                				}
                    			//referenced_pages.push_back(stout[i]);
                			}
            			}
            			//cout<<"hello world\n";
            			count = count + 1;
            		}


		}
	}
	file.close();
}

int main(int argc,char* argv[])
{
	string filename;

	filename  = argv[1];
	cout<<"Filename : "<<filename<<"\n";
	read_file(filename);

	cout<<"No of pages : "<<no_of_pages<<"\n";
	cout<<"No of Frames : "<<no_of_frames<<"\n";

	cout<<"Referenced pages are :\n";
	for(int i=0;i<referenced_pages.size();i++)
    	{
        	cout<<referenced_pages[i]<<" ";
    	}
    	cout<<"\n";
    	if(argc == 2)
    	{
    		FIFO();
    		LFU();
    		LRU();
    	}
    	else if(argc == 3)
    	{
    		if(strcmp(argv[2],"FF") == 0)
    		{
    			FIFO();
    		}
    		else if(strcmp(argv[2],"LF") == 0)
    		{
    			LFU();
    		}
    		else
    		{
    			LRU();
    		}
    	}
	else if(argc == 4)
	{
		if(strcmp(argv[2],"FF") == 0 || strcmp(argv[3],"FF") == 0 )
    		{
    			FIFO();
    		}
    		if(strcmp(argv[2],"LF") == 0 || strcmp(argv[3],"LF") == 0 )
    		{
    			LFU();
    		}
    		if(strcmp(argv[2],"LR") == 0 || strcmp(argv[3],"LR") == 0 )
    		{
    			LRU();
    		}
	}
	else if(argc == 5)
	{
		if(strcmp(argv[2],"FF") == 0 || strcmp(argv[3],"FF") == 0 || strcmp(argv[4],"FF") == 0 )
    		{
    			FIFO();
    		}
    		if(strcmp(argv[2],"LF") == 0 || strcmp(argv[3],"LF") == 0 || strcmp(argv[4],"LF") == 0  )
    		{
    			LFU();
    		}
    		if(strcmp(argv[2],"LR") == 0 || strcmp(argv[3],"LR") == 0 || strcmp(argv[4],"LR") == 0 )
    		{
    			LRU();
    		}
    	}
}


