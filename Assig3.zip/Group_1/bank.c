
// Server side C/C++ program to demonstrate Socket programming 
#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#include <time.h>

#define RESPONSE_BYTES 512

void sendMsgToClient(int clientFD, char *str) {
	int numPacketsToSend = (strlen(str)-1)/RESPONSE_BYTES + 1;
	int n = write(clientFD, &numPacketsToSend, sizeof(int));
	char *msgToSend = (char*)malloc(numPacketsToSend*RESPONSE_BYTES);
	strcpy(msgToSend, str);
	int i;
	for(i = 0; i < numPacketsToSend; ++i) {
		int n = write(clientFD, msgToSend, RESPONSE_BYTES);
		msgToSend += RESPONSE_BYTES;
	}
}

int login_entry_exist(char *id,char *pwd,char *U)
{
	char* filename = "login_entry.txt";
	
	FILE* file = fopen(filename,"r");
	
	char line[100];
	
	while(fgets(line,sizeof(line),file))
	{
		char* token = strtok(line," ");
		
		int count =1;
		int flag = 1;
		
		while(token != NULL)
		{
			if(count == 1)
			{
				if(strcmp(token,id) != 0)
				{
					flag = 0;
					break;
				}
			}
			else if(count == 2)
			{
				if(strcmp(token,pwd) != 0)
				{
					flag = 0;
					break;
				}
			}
			else
			{
				if(token[0] != U[0])
				{
					flag = 0;
					break;
				}
			}
			count = count + 1;
			token = strtok(NULL," ");
		}
		if(flag == 1)
		{
			fclose(file);
			return 1;
		}
				
	}
	fclose(file);
	return 0;
	
}


char* mini_statement_read(char* id)
{
	char filename[10];;
	
	int i = 0;
	
	for(i=0;id[i]!='\0';i++)
	{
		filename[i] = id[i];
	}
	
	filename[i] = '.';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = 'x';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = '\0';
	
	FILE* file = fopen(filename,"r");
	
	//printf("%s\n",filename);
	char line[100];
	
	char* statement = (char*)malloc(100*sizeof(char));
	
	statement[0] = '\0';
	printf("%s",statement);
	
	int count =1;
	
	while(fgets(line,sizeof(line),file))
	{	
		
		if(count > 1)
		{
			strcat(statement,line);
			//printf("%s",line);
		}
		
		count = count + 1; 
		
				
	}
	
	return statement;
}

char* get_curr_balance(char* id)
{
	char filename[10];;
	
	int i = 0;
	for(i=0;id[i]!='\0';i++)
	{
		filename[i] = id[i];
	}
	
	filename[i] = '.';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = 'x';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = '\0';
	
	FILE* file = fopen(filename,"r");
	
	
	char line[100] = {0};
	
	char* balance = (char*)malloc(100*sizeof(char));
	
	balance[0] = '\0';
	
	
	while(fgets(line,sizeof(line),file))
	{ 
		
		strcpy(balance,line);
		fclose(file);
		return balance;		
	}
	fclose(file);
	return line;	
}


/*char* get_date()
{
	char* text = (char*)malloc(50*sizeof(char));
	text[0] = '\0';
	time_t now = time(0);
	struct tm *t = localtime(&now);
	strftime(text,sizeof(text)-1,"%d-%m",t);

	return text;
}*/

void changebalance(char* id,char* amount)
{
	FILE* file,*ftemp;
	
	
	char filename[10];
	
	int i = 0;
	for(i=0;id[i]!='\0';i++)
	{
		filename[i] = id[i];
	}
	
	filename[i] = '.';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = 'x';
	i = i+1;
	filename[i] = 't';
	i = i+1;
	filename[i] = '\0';
	
	file = fopen(filename,"r");
	ftemp = fopen("replace.tmp","w");
	char line[100];
	int count = 0;
	while(fgets(line,sizeof(line),file))
	{	 
		if(count == 0)
		{
			fputs(amount,ftemp);
			fputs("\n",ftemp);
		}
		else
		{
			fputs(line,ftemp);
		}
		count = count + 1;
	}
	fclose(file);
	fclose(ftemp);
	remove(filename);
	rename("replace.tmp",filename);
}

int admin(char* user_id,char *Operation,char* Amount)
{

	char* curr_balance = get_curr_balance(user_id);
	
	printf("%s\n",curr_balance);
	
	int x1 = atoi(Amount);
	int x2 = atoi(curr_balance);
	
	if(strcmp(Operation,"Credit") == 0 || strcmp(Operation,"credit") == 0 )
	{
		int x = x1 + x2;
		char a[10];
		sprintf(a,"%d",x);
		
		// replace balance
		
		
		changebalance(user_id,a);
		
		FILE* fp;
		char filename[10];
	
		int i = 0;
		for(i=0;user_id[i]!='\0';i++)
		{
			filename[i] = user_id[i];
		}
	
		filename[i] = '.';
		i = i+1;
		filename[i] = 't';
		i = i+1;
		filename[i] = 'x';
		i = i+1;
		filename[i] = 't';
		i = i+1;
		filename[i] = '\0';
		
		fp = fopen(filename,"a");
		
		printf("%s\n",filename);
		
		//char* statement;
		//fprintf(fp,"%s",get_date());

		time_t ltime; /* calendar time */
    		ltime=time(NULL); /* get current cal time */
		fprintf(fp, "%.*s",(int)strlen(asctime(localtime(&ltime)))-1, asctime(localtime(&ltime)));

		fprintf(fp," %s",Operation);
		fprintf(fp," %s\n",a);

		fclose(fp);
	}
	else
	{
		if(x1 > x2)
		{
			return 0;
		}
		int x = x2 - x1;
		char a[10];
		sprintf(a,"%d",x);
		changebalance(user_id,a);
		FILE* fp;
		char filename[10];;
	
		int i = 0;
		for(i=0;user_id[i]!='\0';i++)
		{
			filename[i] = user_id[i];
		}
	
		filename[i] = '.';
		i = i+1;
		filename[i] = 't';
		i = i+1;
		filename[i] = 'x';
		i = i+1;
		filename[i] = 't';
		i = i+1;
		filename[i] = '\0';
		
		fp = fopen(filename,"a");
		
		printf("%s\n",filename);
		
		//char* statement;
		
		//fprintf(fp,"%s ",get_date());

		time_t ltime; /* calendar time */
    		ltime=time(NULL); /* get current cal time */
		fprintf(fp, "%.*s",(int)strlen(asctime(localtime(&ltime)))-1, asctime(localtime(&ltime)));		
		
		fprintf(fp,"%s ",Operation);
		fprintf(fp,"%s\n",a);
		fclose(fp);	
	}
	
	return 1;
}

	 
int main(int argc, char const *argv[]) 
{ 
    int nsocket;
	int newSocket;
	int read_val; 
    struct sockaddr_in sock_addr; 
    int option = 1; 
    int lenghOfAddress = sizeof(sock_addr); 
    char buffer[1024] = {0}; 
    //char *hello = "Hello from server"; 
    
    int PortNumber = atoi(argv[1]);  
       
    // Creating socket(file descriptor)
    if ((nsocket = socket(AF_INET, SOCK_STREAM, 0)) == 0) 
    { 
        printf("socket connection failed"); 
        exit(EXIT_FAILURE); 
    } 
       
    if (setsockopt(nsocket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, 
                                                  &option, sizeof(option))) 
    { 
        printf("set socket opt failed"); 
        exit(EXIT_FAILURE); 
    } 

	//Attaching address file
    sock_addr.sin_family = AF_INET; 
    sock_addr.sin_addr.s_addr = INADDR_ANY; 
    sock_addr.sin_port = htons( PortNumber ); 
       
	//Binding with Ip and port ADDRESS
    if (bind(nsocket, (struct sockaddr *)&sock_addr,  
                                 sizeof(sock_addr)) < 0) 
    { 
        printf("Bind connection failed"); 
        exit(EXIT_FAILURE); 
    } 

	//lISTENING...
    if (listen(nsocket, 3) < 0) 
    { 
        printf("Listen failed"); 
        exit(EXIT_FAILURE); 
    } 
    if ((newSocket = accept(nsocket, (struct sockaddr *)&sock_addr,  
                       (socklen_t*)&lenghOfAddress))<0) 
    { 
        printf("Accept failed"); 
        exit(EXIT_FAILURE); 
    } 
    
    /* Waiting for Login */
    char id[5] = {0};
    char pwd[10] = {0};
    char U[2] = {0};
    read_val = read( newSocket ,id, 5); 
    printf("%s\n",id);
    read_val = read( newSocket ,pwd, 10); 
    printf("%s\n",pwd);
    read_val = read( newSocket ,U, 2); 
    printf("%s\n",U);
    
    // verify
    
    int num = login_entry_exist(id,pwd,U);
    if(num == 1)
    {
    	char *login = "1";
    	send(newSocket , login , strlen(login) , 0 ); 
  	
  	if(strcmp(U,"C") == 0)	{

		char* balance = get_curr_balance(id);
		char* statement = mini_statement_read(id);
		sendMsgToClient(newSocket, balance);
		sendMsgToClient(newSocket, statement);
		
	}
	else if(strcmp(U,"A") == 0)
	{
		char user_id[5] = {0},Operation[10]={0},Amount[10]={0};
		
		read_val = read( newSocket ,user_id, 5);     
    		read_val = read( newSocket ,Operation, 10); 
    		read_val = read( newSocket ,Amount, 10); 

    		int num = admin(user_id,Operation,Amount);
    		if(num== 1)
    		{
    			sendMsgToClient(newSocket, "Sucessfully done");
    		}
    		else
    		{
    			sendMsgToClient(newSocket, "Insufficient Balance !!");
    		}
    		
    		// decrease the amount/increase in user_id.txt
    		// update the timestamp entries
	}
	else if(strcmp(U,"P") == 0)
	{
		char user_id[5] = {0};
		read_val = read( newSocket ,user_id, 5); 
		char* statement = mini_statement_read(user_id);
		sendMsgToClient(newSocket, statement);
	} 	
    }
    
    else
    {
    	char *login = "0";
 	send(newSocket , login , strlen(login) , 0 ); 
    }
    printf("--------------------\n");
    return 0; 
} 

