to run bank server -  

gcc bank.c -o bank
./bank 8080

to run client - (bank.c must be run before client.c)

gcc client.c -o client
./client 127.0.0.1 8080 


There are 10 users registered (login_entry.txt) contains their information
There corresponding id.txt(eg. 1.txt) contain their banlance and mini statement



Group 1:

1 . Abhik paul , 204101001
2 . Abhishek Ranjan , 204101002
3 . Aditya Tandon , 204101003
4 . Ajay Gahlot , 204101004
