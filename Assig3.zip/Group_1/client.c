// Client side C/C++ program to demonstrate Socket programming 
#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h> 

#define RESPONSE_BYTES 512

void msg(char *str) {
	printf("%s", str);
}

char* receiveMsgFromServer(int sockFD) {
	int numPacketsToReceive = 0;
	int n = read(sockFD, &numPacketsToReceive, sizeof(int));
	if(n <= 0) {
		shutdown(sockFD, SHUT_WR);
		return NULL;
	}
	char *str = (char*)malloc(numPacketsToReceive*RESPONSE_BYTES);
	memset(str, 0, numPacketsToReceive*RESPONSE_BYTES);
	char *str_p = str;
	int i;
	for(i = 0; i < numPacketsToReceive; ++i) {
		int n = read(sockFD, str, RESPONSE_BYTES);
		str = str+RESPONSE_BYTES;
	}
	return str_p;
}

int main(int argc, char const *argv[]) 
{ 
	int sock = 0, read_val; 
	struct sockaddr_in sock_addr; 
	char buffer[1024] = {0}; 
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 
	int PORT = atoi(argv[2]);
	sock_addr.sin_family = AF_INET; 
	sock_addr.sin_port = htons(PORT); 
	
	// Convert IPv4 and IPv6 addresses 
	if(inet_pton(AF_INET, argv[1], &sock_addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address or address not supported \n"); 
		return -1; 
	} 

	if (connect(sock, (struct sockaddr *)&sock_addr, sizeof(sock_addr)) < 0) 
	{ 
		printf("\nConnection Failed \n"); 
		return -1; 
	} 
	
	// login process
	
	char id[5];
	char password[10];
	char U[2];
	printf("Enter the user Id\n");
	scanf("%s",id);
	send(sock ,id,strlen(id) , 0 );
	printf("Enter the password\n");
	scanf("%s",password);
	send(sock ,password,strlen(password) , 0 );
	printf("Enter the User type(C - customer/A - admin/P-police)\n")  ;
	scanf("%s",U);
	send(sock ,U,strlen(U) , 0 );
	
	read_val = read( sock , buffer, 1); 

	  if(buffer[0] == '1')
	  {
		printf("Login Successful !! \n\n");
		
		if(strcmp(U,"C") == 0)
		{
			printf("Welcome Customer\n\n");
			char *msgFromServer;
			printf("Available Balance \n");
			msgFromServer = receiveMsgFromServer(sock);
			msg(msgFromServer);
			msg("\n");
			free(msgFromServer);
			printf("Bank Statement \n");
			msgFromServer = receiveMsgFromServer(sock);
			msg(msgFromServer);
			msg("\n");
			free(msgFromServer);
		}
		else if(strcmp(U,"A") == 0)
		{
			printf("Welcome Admin\n");
			
			char user_id[5],Operation[2],Amount[10];
			printf("Enter the User id which you want to open\n");
			scanf("%s",user_id);
			send(sock ,user_id,strlen(user_id) , 0 );
			printf("Operation - Debit/Credit (type Credit or Debit)\n");
			scanf("%s",Operation);
			send(sock ,Operation,strlen(Operation) , 0 );
			printf("Amount\n");
			scanf("%s",Amount);
			send(sock ,Amount,strlen(Amount) , 0 );
			
			char *msgFromServer;
			msgFromServer = receiveMsgFromServer(sock);
			msg(msgFromServer);
			msg("\n");
			free(msgFromServer);
			
		}
		else 
		{
			printf("welcome Police\n");
			// all availabe balance
			char user_id[5];
			printf("Enter the User id which you want to see mini statement\n");
			scanf("%s",user_id);
			send(sock ,user_id,strlen(user_id) , 0 );
			char *msgFromServer;
			msgFromServer = receiveMsgFromServer(sock);
			msg(msgFromServer);
			msg("\n");
			free(msgFromServer);
		}
		
	}
	else
	{
		printf("Wrong details\n");
	}
	return 0; 
} 

